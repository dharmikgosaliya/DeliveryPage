// // Example: Toggle menu on small screens
// document.addEventListener('DOMContentLoaded', () => {
//     const menuToggle = document.querySelector('.menu-toggle');
//     const nav = document.querySelector('nav');

//     menuToggle.addEventListener('click', () => {
//         nav.classList.toggle('open');
//     });
// });


// Ensure the DOM is fully loaded before running the script
document.addEventListener('DOMContentLoaded', () => {
    const loadMoreButton = document.getElementById('load-more-dishes');
    const dishContainer = document.getElementById('dish-container');

    // Initial dishes to display
    let dishes = [
        { name: 'Matoke', image: 'dish1.jpg', description: 'Popular plantain dish...' },
        { name: 'Posho', image: 'dish2.jpg', description: 'Maize porridge dish...' },
        { name: 'Luwombo', image: 'dish3.jpg', description: 'Stew made with groundnut sauce...' }
    ];

    // Function to load dishes
    function loadDishes(dishArray) {
        dishArray.forEach(dish => {
            const dishCard = document.createElement('div');
            dishCard.className = 'dish-card';
            dishCard.innerHTML = `
                <img src="${dish.image}" alt="${dish.name}">
                <div class="dish-info">
                    <h3>${dish.name}</h3>
                    <p>${dish.description}</p>
                </div>
            `;
            dishContainer.appendChild(dishCard);
        });
    }

    // Load initial dishes
    loadDishes(dishes);

    // Event listener for 'Load More Dishes' button
    loadMoreButton.addEventListener('click', () => {
        // Example data for additional dishes to load
        const moreDishes = [
            { name: 'Kamatore', image: 'dish4.jpg', description: 'Delicious fried meat...' },
            { name: 'Kabalagala', image: 'dish5.jpg', description: 'Fried plantain slices...' }
        ];

        // Load more dishes
        loadDishes(moreDishes);

        // Optionally, disable the button after loading more dishes
        // loadMoreButton.disabled = true;
    });
});
